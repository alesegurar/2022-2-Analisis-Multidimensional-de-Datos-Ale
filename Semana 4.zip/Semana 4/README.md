# 2022-2-Analisis
repo para el curso análisis multidimensional ii cuatri 2022
